﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MachineTestApp
{
    public partial class Productentryform : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-813DS1U\SQLEXPRESS;Initial Catalog=MachineTestDB;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        public Productentryform()
        {
            InitializeComponent();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Loadcolorcombo();
        }

        private void Loadcolorcombo()
        {
            {
                DataRow dr;
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from Color_Master", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                dr = dt.NewRow();
                dr.ItemArray = new object[] { 0, "--Select Color--" };
                dt.Rows.InsertAt(dr, 0);

                cbColor.ValueMember = "Color_Id";

                cbColor.DisplayMember = "Color_Name";
                cbColor.DataSource = dt;

                con.Close();
            }      
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            bool isValid = (dtpPurchasedate.Value < dtpExpirydate.Value);
           int j= checkExixt();
           if (j == 0)
           {
               if (isValid)
               {

                   {
                       cmd = new SqlCommand("insert into ProductentryformDB(Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Id) values(@Name,@price,@Quantity,@IsGSTApplicable,@Purchase_Date,@Expiry_date,@Color_Id)", con);
                       con.Open();
                       cmd.Parameters.AddWithValue("@Name", txtName.Text);
                       cmd.Parameters.AddWithValue("@price", txtprise.Text);
                       cmd.Parameters.AddWithValue("@Quantity", txtquantity.Text);
                       if (rbGst.Checked == true)
                       {
                           cmd.Parameters.AddWithValue("@IsGSTApplicable", true);
                       }
                       else
                       {
                           cmd.Parameters.AddWithValue("@IsGSTApplicable", false);
                       }
                       cmd.Parameters.AddWithValue("@Purchase_Date", dtpPurchasedate.Value);
                       cmd.Parameters.AddWithValue("@Expiry_date", dtpExpirydate.Value);
                       cmd.Parameters.AddWithValue("@Color_Id", cbColor.SelectedValue);
                       int i = cmd.ExecuteNonQuery();
                       con.Close();
                       MessageBox.Show("Record Inserted Successfully");
                       
                       GridtodisplayProductlist Obj = new GridtodisplayProductlist();
                       this.Hide();
                       Obj.Show();

                       ClearData();
                   }
               }
               else
               {
                   MessageBox.Show("Purchase date should not be greatter than Expire date");
               }
           }
           else
           {
               MessageBox.Show("Product name is already exist");
           }

        }

        private int checkExixt()
        {
            DataTable dt = new DataTable();
            string name = txtName.Text;
            adapt = new SqlDataAdapter("select Id,Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Name " +
                                        "from ProductentryformDB PD inner join dbo.Color_Master CM on " +
                                        "PD.Color_Id=CM.Color_Id where Name='" + name + "'", con);
            adapt.Fill(dt);

            return dt.Rows.Count;
        }
        private void ClearData()
        {
            txtName.Text = "";
            txtprise.Text = "";
            txtquantity.Text = "";
            rbGst.Checked = false;
            dtpPurchasedate.CustomFormat = " ";
            dtpExpirydate.CustomFormat = " ";
            cbColor.SelectedIndex = 0;
        }


    }
}

