﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Office.Interop.Excel;
using System.IO;
using ClosedXML.Excel;

namespace MachineTestApp
{
        
    public partial class GridtodisplayProductlist : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-813DS1U\SQLEXPRESS;Initial Catalog=MachineTestDB;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        public GridtodisplayProductlist()
        {
            InitializeComponent();
        }

        
        private void DisplayData()
        {
           
            adapt = new SqlDataAdapter("select Id,Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Name "+
                                        "from ProductentryformDB PD inner join dbo.Color_Master CM on "+
                                        "PD.Color_Id=CM.Color_Id", con);
            Bindgrid(adapt);
        }
        private void Bindgrid(SqlDataAdapter adapter)
        {
         con.Open();
         System.Data.DataTable dt = new System.Data.DataTable();
            adapter.Fill(dt);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.Columns[0].DataPropertyName = "Name";
            dataGridView1.Columns[1].DataPropertyName = "price";
            dataGridView1.Columns[2].DataPropertyName = "Quantity";
            dataGridView1.Columns[3].DataPropertyName = "IsGSTApplicable";
            dataGridView1.Columns[4].DataPropertyName = "Purchase_Date";
            dataGridView1.Columns[5].DataPropertyName = "Expiry_date";
            dataGridView1.Columns[6].DataPropertyName = "Color_Name";
            dataGridView1.DataSource = dt;

            con.Close();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        

        private void GridtodisplayProductlist_Load(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtSearch.Text;
            adapt = new SqlDataAdapter("select Id,Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Name " +
                                        "from ProductentryformDB PD inner join dbo.Color_Master CM on " +
                                        "PD.Color_Id=CM.Color_Id where Name='" + name + "'", con);
            Bindgrid(adapt);
        }

        private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
            DataGridViewColumn colind = dataGridView1.Columns[e.ColumnIndex];
            if (colind.Name == "Name")
            {
                adapt = new SqlDataAdapter("select Id,Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Name " +
                                       "from ProductentryformDB PD inner join dbo.Color_Master CM on " +
                                       "PD.Color_Id=CM.Color_Id order by Name", con);
                Bindgrid(adapt);

            }
            else if (colind.Name == "Purchase_Date")
            {
                adapt = new SqlDataAdapter("select Id,Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Name " +
                                       "from ProductentryformDB PD inner join dbo.Color_Master CM on " +
                                       "PD.Color_Id=CM.Color_Id order by Purchase_Date", con);
                Bindgrid(adapt);

            }
            else if (colind.Name == "Expiry_date")
            {
                adapt = new SqlDataAdapter("select Id,Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Name " +
                                       "from ProductentryformDB PD inner join dbo.Color_Master CM on " +
                                       "PD.Color_Id=CM.Color_Id order by Expiry_date", con);
                Bindgrid(adapt);

            }
            else {
                adapt = new SqlDataAdapter("select Id,Name,price,Quantity,IsGSTApplicable,Purchase_Date,Expiry_date,Color_Name " +
                                           "from ProductentryformDB PD inner join dbo.Color_Master CM on " +
                                           "PD.Color_Id=CM.Color_Id", con);
                Bindgrid(adapt);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            //Creating DataTable
            System.Data.DataTable dt = new System.Data.DataTable();

            //Adding the Columns
            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                dt.Columns.Add(column.HeaderText, column.ValueType);
            }
            int cnt = dataGridView1.Rows.Count;
            cnt = cnt - 1;
            //Adding the Rows
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                dt.Rows.Add();
                foreach (DataGridViewCell cell in row.Cells)
                {
                    dt.Rows[dt.Rows.Count - 1][cell.ColumnIndex] = cell.Value.ToString();
                }
                if (cnt == dt.Rows.Count)
                {
                    break;
                }
            }

            //Exporting to Excel
            string folderPath = "C:\\Excel\\";
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt, "Customers");
                wb.SaveAs(folderPath + "DataGridViewExport.xlsx");
                MessageBox.Show("Excel is exported in C:\\Excel\\ ");
            }
        }
    }
}
